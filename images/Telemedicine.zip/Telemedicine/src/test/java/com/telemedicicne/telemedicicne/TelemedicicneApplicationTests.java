package com.telemedicicne.telemedicicne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelemedicicneApplicationTests {

	@Test
	void contextLoads() {
	}

}
