//package com.telemedicicne.telemedicicne.videoCallConfig;
//
//public class VideoCallRequest {
//    private String callerUsername;
//    private String calleeUsername;
//
//    public VideoCallRequest(String callerUsername, String calleeUsername) {
//        this.callerUsername = callerUsername;
//        this.calleeUsername = calleeUsername;
//    }
//
//    // Getters and setters
//    public String getCallerUsername() {
//        return callerUsername;
//    }
//
//    public void setCallerUsername(String callerUsername) {
//        this.callerUsername = callerUsername;
//    }
//
//    public String getCalleeUsername() {
//        return calleeUsername;
//    }
//
//    public void setCalleeUsername(String calleeUsername) {
//        this.calleeUsername = calleeUsername;
//    }
//}
//
