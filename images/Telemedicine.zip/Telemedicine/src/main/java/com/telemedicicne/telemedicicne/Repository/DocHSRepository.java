package com.telemedicicne.telemedicicne.Repository;




import com.telemedicicne.telemedicicne.Entity.DocHs;
import com.telemedicicne.telemedicicne.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DocHSRepository extends JpaRepository<DocHs, Long> {

//    public Optional<DocHs> findByEmail(String email);
List<DocHs> findByRoles_Name(String roleName);

    public Optional<DocHs> findByEmail(String email);

    DocHs findByDocHsId(Long refId); // Add this method

}
