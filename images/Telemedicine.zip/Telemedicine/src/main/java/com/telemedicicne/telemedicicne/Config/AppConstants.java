// User role - Admin vs Normal

package com.telemedicicne.telemedicicne.Config;

public class AppConstants {

    public static final Integer SUB_ADMIN = 502;
    public static final Integer MASTER_ADMIN = 501;
//    public static final Integer SUB_ADMIN = 503;


    public static final Integer DOCTOR = 504;
    public static final Integer PATIENT = 505;
    public static final Integer HEALTH_OFFICER = 503;
//    public static final Integer ADMIN = 501;

}
